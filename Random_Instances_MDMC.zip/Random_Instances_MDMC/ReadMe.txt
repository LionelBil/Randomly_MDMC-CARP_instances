nodes edges tasks
Q1 Q2
depots
node1 node2 cost demand1 demad2
 
